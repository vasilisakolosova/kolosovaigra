﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bobrutskov
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            double a = Convert.ToInt32(textBox1.Text);
            double b = Convert.ToInt32(textBox2.Text);
            double c = Convert.ToInt32(textBox3.Text);
            double BMRm = 665 + (13.7 * b) + (5 * a) - (6.8 * c);
            label11.Text = Convert.ToString(BMRm);
            double bmrmsit = BMRm * 1.2;
            label18.Text = Convert.ToString(bmrmsit);
            double bmrmm = BMRm * 1.375;
            label19.Text = Convert.ToString(bmrmm);
            double bmrmactiv = BMRm * 1.55;
            label20.Text = Convert.ToString(bmrmactiv);
            double bmrmveryactiv = BMRm * 1.725;
            label21.Text = Convert.ToString(bmrmveryactiv);
            double bmrmsport = BMRm * 1.9;
            label22.Text = Convert.ToString(bmrmsport);

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            double a = Convert.ToInt32(textBox1.Text);
            double b = Convert.ToInt32(textBox2.Text);
            double c = Convert.ToInt32(textBox3.Text);
            double BMRm = 66 + (13.7 * b) + (5 * a) - (6.8 * c);
            label11.Text = Convert.ToString(BMRm);
            double bmrmsit = BMRm * 1.2;
            label18.Text = Convert.ToString(bmrmsit);
            double bmrmm = BMRm * 1.375;
            label19.Text = Convert.ToString(bmrmm);
            double bmrmactiv = BMRm * 1.55;
            label20.Text = Convert.ToString(bmrmactiv);
            double bmrmveryactiv = BMRm * 1.725;
            label21.Text = Convert.ToString(bmrmveryactiv);
            double bmrmsport = BMRm * 1.9;
            label22.Text = Convert.ToString(bmrmsport);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }
    }
}
