﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace maraphon31
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox1.Image;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox2.Image;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double a = Convert.ToInt32(textBox4.Text);
            double b = Convert.ToInt32(textBox5.Text);
            double c = a / 100;
            double bmi = b / (c * c);

            if (bmi < 10)
            { trackBar1.Value = 10; }
            label13.Visible = true;
            if (bmi < 19) { label13.Text = "Недостаточный"; }
            if (bmi < 25) { label13.Text = "Здоровый"; }
            if (bmi < 35) { label13.Text = "Избыточный"; }
            if (bmi > 35) { label13.Text = "Ожирение"; }
            if (bmi > 40)
            { trackBar1.Value = 40; }
            else { trackBar1.Value = Convert.ToInt32 (bmi); }
            label12.Text = Convert.ToString(bmi);
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }
    }
}
