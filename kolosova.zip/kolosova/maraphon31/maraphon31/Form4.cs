﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace maraphon31
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            DateTime date = new DateTime(2022, 10, 21, 18, 30, 25);
            DateTime date1 = DateTime.Today;

            label2.Text = Convert.ToString(date.Subtract(date1)) + " до старта марафона!";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form.form6 = new Login();
            Form6.Show(); 
        }
    }
}
