﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace maraphon31
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            textBox1.Text = "Avenida Rudge";
            pictureBox10.Visible = false;
            pictureBox9.Visible = false;
            pictureBox8.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
           
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = "Theatro Municipal";
            panel1.Visible = true;

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            textBox1.Text = "Race start";
            textBox7.Text = "Samba Full Marathon";
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            pictureBox10.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
           
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            textBox1.Text = "Начало 42 км полный марафон";
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            pictureBox10.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox7.Visible = false;



        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
           
            pictureBox10.Visible = false;
         
            textBox6.Visible = false;
            textBox1.Text = "Jardim Luzitania";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            pictureBox8.Visible = false;
            textBox4.Visible = false;
            pictureBox10.Visible = false;
            textBox6.Visible = false;
            textBox1.Text = "Parque do Ibirapuera";


        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            pictureBox8.Visible = false;
            panel1.Visible = true;
            textBox4.Visible = false;
            textBox1.Text = "Iguatemi";

        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            pictureBox8.Visible = false;
            textBox4.Visible = false;
            pictureBox10.Visible = false;
            textBox6.Visible = false;
            textBox1.Text = "Rua Lisboa";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            textBox1.Text = "Cemitério da Consolação";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            textBox1.Text = "Cemitério da Consolação";
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            textBox1.Text = " Half Marathon ";
            textBox7.Text = " Начало 21km  ";
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            pictureBox10.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox7.Visible = false;

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Fun Run ";
            textBox7.Text = "- 5 км до конца курса. ";
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            pictureBox10.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox7.Visible = false;
        }
    }
}
