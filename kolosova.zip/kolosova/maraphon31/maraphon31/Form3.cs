﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace maraphon31
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a = Convert.ToInt32(textBox5.Text);
            double b = Convert.ToInt32(textBox6.Text);
            double c = Convert.ToInt32(textBox7.Text);
            double bmi = 66 + (13.7 * b) + (5 * a) - (6.8 * c);
            label10.Text = Convert.ToString(bmi);
            double bmi1 = bmi * 1.2;
            label17.Text = Convert.ToString(bmi1);
            double bmi2 = bmi * 1.375;
            label18.Text = Convert.ToString(bmi2);
            double bmi3 = bmi * 1.55;
            label19.Text = Convert.ToString(bmi3);
            double bmi4 = bmi * 1.725;
            label20.Text = Convert.ToString(bmi4);
            double bmi5 = bmi * 1.9;
            label21.Text = Convert.ToString(bmi5);

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
