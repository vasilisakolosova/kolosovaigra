﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kolosovam1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // в консоле выводится текст
            Console.Write("Введите количество элементов массива:\t");
            //вводится целочисленая переменная под именем elementCount
            //присвоением значения от преобразования в целое число
            //строки символов из стандартного входного потока
            int n = int.Parse(Console.ReadLine());
            // вводится целочисленый массив под именем myArray
            // по числу элементов elementsCount
            int[] myArray = new int[n];
            //генерируются случайные числа
            Random rand = new Random();
            //выводится массив
            Console.Write("Массив: ");
            for (int i = 0; i < n; i++)
                //задаётся случайные числа от и до после ведённого количества чисел
                Console.Write("{0} ", myArray[i] = rand.Next(1, 42));
            //задаётся переменная max
            int max = myArray[0];
            //вычисление минимального нечётного значения
            for (int i = 0; i < n; i += 2)
                if (max > myArray[i])
                { max = myArray[i]; }
            //вывод максимального чётного элемента
            Console.WriteLine("\nМаксимальный элемент среди четных элементов массива: {0}", "120 " + max);
            Console.ReadKey();





        }
    }
}
